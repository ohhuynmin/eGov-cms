package egovframework.example.sample.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.sample.dao.CategoryDao;
import egovframework.example.sample.service.CategoryService;
import egovframework.example.sample.vo.CategoryVo;

@Service
public class CategoryServiceImpl implements CategoryService{
	@Autowired
	private CategoryDao categoryDao;
	
	@Override
	public List<CategoryVo> selectCategoryList() throws Exception {
		return categoryDao.selectCategoryList();
	}

	@Override
	public CategoryVo selectCategory(CategoryVo categoryVo) throws Exception {
		return categoryDao.selectCategory(categoryVo);
	}

	@Override
	public void createCategory(CategoryVo categoryVo) throws Exception {
		categoryDao.createCategory(categoryVo);
		
	}

	@Override
	public void deleteCategory(CategoryVo categoryVo) throws Exception {
		categoryDao.deleteCategory(categoryVo);
		
	}
	@Override
	public List<CategoryVo> selectMainCategoryList() throws Exception{
		return categoryDao.selectMainCategoryList();
	}
	@Override
	public List<CategoryVo> selectSubCategoryList(int main_id) throws Exception{
		return categoryDao.selectSubCategoryList(main_id);
	}
}

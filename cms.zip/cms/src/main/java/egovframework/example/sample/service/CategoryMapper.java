package egovframework.example.sample.service;

import java.util.List;

import egovframework.example.sample.vo.CategoryVo;

public interface CategoryMapper {
	List<CategoryVo> selectCategoryList() throws Exception;
	CategoryVo selectCategory(CategoryVo categoryVo) throws Exception;
	void createCategory(CategoryVo categoryVo) throws Exception;
	void deleteCategory(CategoryVo categoryVo) throws Exception;
	public List<CategoryVo> selectMainCategoryList() throws Exception;
	public List<CategoryVo> selectSubCategoryList(int main_id) throws Exception;
}

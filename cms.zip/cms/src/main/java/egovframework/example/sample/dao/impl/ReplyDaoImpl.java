package egovframework.example.sample.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import egovframework.example.sample.dao.ReplyDao;
import egovframework.example.sample.service.ReplyMapper;
import egovframework.example.sample.vo.ReplyVo;

@Repository
public class ReplyDaoImpl implements ReplyDao{
	 @Autowired
	 private SqlSession sqlSession;
	ReplyMapper mapper;
	
	@Override
	public List<ReplyVo> replyList(ReplyVo replyVo) throws Exception {
		mapper = sqlSession.getMapper(ReplyMapper.class);
		return mapper.replyList(replyVo);
	}

	@Override
	public void createReply(ReplyVo replyVo) throws Exception {
		mapper = sqlSession.getMapper(ReplyMapper.class);
		mapper.createReply(replyVo);
	}

	@Override
	public void deleteReply(ReplyVo replyVo) throws Exception {
		mapper = sqlSession.getMapper(ReplyMapper.class);
		mapper.deleteReply(replyVo);
	}

	@Override
	public int count(ReplyVo replyVo) throws Exception {
		mapper = sqlSession.getMapper(ReplyMapper.class);
		return mapper.count(replyVo);
	}

}

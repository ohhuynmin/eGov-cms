package egovframework.example.sample.service;

import java.util.List;

import egovframework.example.sample.vo.ReplyVo;

public interface ReplyService {
	public List<ReplyVo> replyList(ReplyVo replyvo) throws Exception;
	public int count(ReplyVo replyvo) throws Exception;
	public void createReply(ReplyVo replyvo) throws Exception;
	public void deleteReply(ReplyVo replyvo) throws Exception;
}

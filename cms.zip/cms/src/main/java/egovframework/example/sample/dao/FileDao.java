package egovframework.example.sample.dao;

import egovframework.example.sample.vo.FileVo;

public interface FileDao {
	public FileVo selectFile(FileVo fileVo) throws Exception;
	public void addFile(FileVo fileVo) throws Exception;
	public void deleteFile(String fileId) throws Exception;
}

package egovframework.example.sample.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.sample.dao.BoardDao;
import egovframework.example.sample.service.BoardService;
import egovframework.example.sample.vo.BoardVo;
import egovframework.example.sample.vo.SearchVo;

@Service
public class BoardServiceImpl implements BoardService{
	@Autowired
	private BoardDao boardDao;
	@Override
	public List<BoardVo> selectBoardList(SearchVo searchVo) throws Exception {
		return boardDao.selectBoardList(searchVo);
	}

	@Override
	public BoardVo selectBoard(BoardVo boardVo) throws Exception {
		return boardDao.selectBoard(boardVo);
	}

	@Override
	public void createBoard(BoardVo boardVo) throws Exception {
		boardDao.createBoard(boardVo);
		
	}

	@Override
	public void deleteBoard(BoardVo boardVo) throws Exception {
		boardDao.deleteBoard(boardVo);
	}

	@Override
	public void updateBoard(BoardVo boardVo) throws Exception {
		boardDao.updateBoard(boardVo);
	}

	@Override
	public int countBoard(SearchVo searchVo) throws Exception {
		return boardDao.countBoard(searchVo);
	}

}

package egovframework.example.sample.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import egovframework.example.sample.dao.BoardDao;
import egovframework.example.sample.service.BoardMapper;
import egovframework.example.sample.vo.BoardVo;
import egovframework.example.sample.vo.SearchVo;

@Repository
public class BoardDaoImpl implements BoardDao{
	@Autowired
	 private SqlSession sqlSession;
	BoardMapper mapper;
	
	@Override
	public List<BoardVo> selectBoardList(SearchVo searchVo) throws Exception {
		mapper = sqlSession.getMapper(BoardMapper.class);
		return mapper.selectBoardList(searchVo);
	}
	@Override
	public BoardVo selectBoard(BoardVo boardVo) throws Exception {
		mapper = sqlSession.getMapper(BoardMapper.class);
		return mapper.selectBoard(boardVo);
	}
	@Override
	public void createBoard(BoardVo boardVo) throws Exception {
		mapper = sqlSession.getMapper(BoardMapper.class);
		mapper.createBoard(boardVo);
	}
	@Override
	public void deleteBoard(BoardVo boardVo) throws Exception {
		mapper = sqlSession.getMapper(BoardMapper.class);
		mapper.deleteBoard(boardVo);
	}
	@Override
	public void updateBoard(BoardVo boardVo) throws Exception {
		mapper = sqlSession.getMapper(BoardMapper.class);
		mapper.updateBoard(boardVo);
	}
	@Override
	public int countBoard(SearchVo searchVo) throws Exception {
		mapper = sqlSession.getMapper(BoardMapper.class);
		return mapper.countBoard(searchVo);
		
	}
	

}

package egovframework.example.sample.service;

import egovframework.example.sample.vo.FileVo;

public interface FileService {
	public FileVo selectFile(FileVo fileVo) throws Exception;
	public void addFile(FileVo fileVo) throws Exception;
	public void deleteFile(String fileId) throws Exception;
}

package egovframework.example.sample.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.sample.dao.FileDao;
import egovframework.example.sample.service.FileService;
import egovframework.example.sample.vo.FileVo;

@Service
public class FileServiceImpl implements FileService{

	@Autowired
	private FileDao fileDao;
	@Override
	public FileVo selectFile(FileVo fileVo) throws Exception {	
		return fileDao.selectFile(fileVo);
	}

	@Override
	public void addFile(FileVo fileVo) throws Exception {
		fileDao.addFile(fileVo);
		
	}

	@Override
	public void deleteFile(String fileId) throws Exception {
		fileDao.deleteFile(fileId);
	}

}

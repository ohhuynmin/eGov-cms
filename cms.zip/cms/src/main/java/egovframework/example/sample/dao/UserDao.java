package egovframework.example.sample.dao;

import java.util.List;

import egovframework.example.sample.vo.UserVo;

public interface UserDao {
	public UserVo login(UserVo userVo) throws Exception;
	public void signup(UserVo userVo) throws Exception;
	public void signout(UserVo userVo) throws Exception;
	public void updateUser(UserVo userVo) throws Exception;
	public UserVo findPwd(UserVo userVo) throws Exception;
	public List<UserVo> userList() throws Exception;
	
}

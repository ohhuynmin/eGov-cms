package egovframework.example.sample.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import egovframework.example.sample.service.FileService;
import egovframework.example.sample.vo.FileVo;

@Controller
public class FileController {
	@Autowired
	private FileService fileservice;	
	
	@RequestMapping(value="fileDownload.do")
	public void fileDownload(HttpServletRequest req, HttpServletResponse res) throws Exception {
		FileVo fileVo = new FileVo();
		fileVo.setName(req.getParameter("fileName"));
		fileVo.setId(req.getParameter("fileId"));
		FileVo selectFile = fileservice.selectFile(fileVo);
        String realFilepath = selectFile.getPath();
        String fileName = selectFile.getId() +"_"+ selectFile.getName();
        
        realFilepath += "/"+fileName;
        File file = new File(realFilepath);
        if (!file.exists()) {
            return;
        }
     // 파일명 지정
        res.setContentType("application/octer-stream;charset=utf-8");
        res.setHeader("Content-Transfer-Encoding", "binary");
        res.setHeader("Content-Disposition", "attachment; filename=\""+ URLEncoder.encode(selectFile.getName(),"UTF-8").replace("+", " ")+"\";");
 
        try {
            OutputStream os = res.getOutputStream();
            FileInputStream fis = new FileInputStream(realFilepath);
            
            
            int cnt = 0;
            byte[] bytes = new byte[512];	 //512bytes씩 끊어서 전송 
 
            while ((cnt = fis.read(bytes)) != -1) {
                os.write(bytes, 0, cnt);
            }
            fis.close();
            os.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}

}

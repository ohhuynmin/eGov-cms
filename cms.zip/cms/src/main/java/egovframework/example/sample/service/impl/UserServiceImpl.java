package egovframework.example.sample.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.sample.dao.UserDao;
import egovframework.example.sample.service.CryptPassword;
import egovframework.example.sample.service.UserService;
import egovframework.example.sample.vo.UserVo;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserDao userdao;
	String pass;
	
	@Override
	public UserVo login(UserVo userVo) throws Exception {
		pass = CryptPassword.encrypt(userVo.getPwd(), userVo.getEmail());
		userVo.setPwd(pass);
		return userdao.login(userVo);
	}

	@Override
	public void signup(UserVo userVo) throws Exception {
		pass = CryptPassword.encrypt(userVo.getPwd(), userVo.getEmail());
		userVo.setPwd(pass);
		userdao.signup(userVo);		
	}

	@Override
	public void signout(UserVo userVo) throws Exception {
		userdao.signout(userVo);		
	}

	@Override
	public void updateUser(UserVo userVo) throws Exception {
		if(userVo.getPwd() != null && userVo.getEmail() != null) {
			pass = CryptPassword.encrypt(userVo.getPwd(), userVo.getEmail());
			userVo.setPwd(pass);
		}
		userdao.updateUser(userVo);				
	}

	@Override
	public UserVo findPwd(UserVo userVo) throws Exception {
		return userdao.findPwd(userVo);
	}
	@Override
	public List<UserVo> userList() throws Exception{
		return userdao.userList();
	}

}

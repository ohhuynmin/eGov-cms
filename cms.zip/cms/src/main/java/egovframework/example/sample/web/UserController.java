package egovframework.example.sample.web;

import java.io.PrintWriter;
import java.util.List;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import egovframework.example.sample.service.CategoryService;
import egovframework.example.sample.service.CryptPassword;
import egovframework.example.sample.service.TempKey;
import egovframework.example.sample.service.UserService;
import egovframework.example.sample.vo.UserVo;

@Controller
public class UserController {
	@Autowired
	private UserService userService;
	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private CategoryService categoryService;
	
//	로그인페이지, 로그인성공시 게시판 리스트
	@RequestMapping(value = "/home.do")
	public String loginPage(HttpServletRequest req,Model model) throws Exception{
		HttpSession session = req.getSession();
		if(session.getAttribute("user") != null) {
			model.addAttribute("categoryList", categoryService.selectCategoryList());
			return "sample/home";
		}else return "sample/loginPage";
	}
	
//	로그인 
	@RequestMapping(value="/login.do", method=RequestMethod.POST)
	public String login(UserVo userVo,HttpServletRequest req) throws Exception{
		HttpSession session = req.getSession();
		UserVo loginUserVo = userService.login(userVo);
		if(loginUserVo != null) {
			session.setAttribute("user", loginUserVo);
		}	
		return "redirect:/home.do";	
	}
//	로그아웃 
	@RequestMapping(value="/logout.do")
	public String logout(HttpServletRequest req) throws Exception{
		req.getSession().invalidate(); //세션 초기화 
		return "redirect:/";
	}
//	회원가입 페이지
	@RequestMapping(value="/signupView.do")
	public String signupView() throws Exception{	
		return "sample/signup";
	}
//	인증번호 or 비밀번호 찾기
	@RequestMapping(value="/checkUser.do")
	public @ResponseBody String checkUser(UserVo userVo, @RequestParam(value="email")String email,
			@RequestParam(value="name", defaultValue = "")String name, HttpServletResponse res) throws Exception{
			userVo.setEmail(email);
			String type ="";
			System.out.println(name);
			if(name.equals("")) {
				type = "findPwd";
			}else {
				type = "signup";
			}
			
			System.out.println(type);
			UserVo checkVo = userService.findPwd(userVo);
			if(type.equals("findPwd")) {
				if(checkVo != null) {	
					System.out.println("findpwd");
					String pass = sendMail(userVo, res, type);
					userVo.setPwd(pass);
					userService.updateUser(userVo);
					return "success";
				}else return "";
				
			}else if(type.equals("signup")) {
				if(checkVo == null) {
					System.out.println("signup");
					return sendMail(userVo, res, type);
				}else return "";
				
			}else return "";
	}
//	회원가입
	@RequestMapping(value="signup.do")
	public String signup(UserVo userVo) throws Exception{
		userService.signup(userVo);
		return "redirect:/home.do";
	}
//	회원탈퇴
	@RequestMapping(value="signout.do")
	public @ResponseBody String signout(UserVo userVo, HttpServletRequest req) throws Exception{
		UserVo loginedVo = (UserVo)req.getSession().getAttribute("user");
		String pass = CryptPassword.encrypt(userVo.getPwd(), userVo.getEmail());
		if(loginedVo.getPwd().equals(pass)) {
			userVo.setPwd(pass);
			userService.signout(userVo);
			req.getSession().invalidate();
			return "success";
		}else return "failed";
	}
//	유저관리
	@RequestMapping(value="userManagement.do")
	public String userManagement(Model model) throws Exception{
		model.addAttribute("userList", userService.userList());
		return "sample/userManagement";
	}
//	유저 권한 변경
	@RequestMapping(value="changeAuthority.do")
	public void permissionUp(@RequestParam(value="userId[]")List<String> id,@RequestParam(value="authority")String authority) throws Exception{
		UserVo userVo = new UserVo();
		for(int i=0; i<id.size();i++) {
			userVo.setId(Integer.parseInt(id.get(i)));
			userVo.setAuthority(authority);
			System.out.println(userVo.getId()+"/"+userVo.getAuthority());
			userService.updateUser(userVo);
		}
	}
//	마이페이지 이동
	@RequestMapping(value="myPageView.do")
	public String myPageView(HttpServletRequest req, Model model) throws Exception{
		UserVo userVo = (UserVo)req.getSession().getAttribute("user");
		if(userVo != null) {
			return "userPage/myPage";
		} else return "redirect:/home.do";
	}
//	비밀번호 변경
	@RequestMapping(value="updateUser.do")
	public @ResponseBody String updateUser(UserVo userVo, HttpServletRequest req, @RequestParam(value="cur_pwd")String cur_pwd) throws Exception{
		UserVo loginedVo = (UserVo)req.getSession().getAttribute("user");
		String pass = CryptPassword.encrypt(cur_pwd, userVo.getEmail());
		System.out.println(loginedVo.getPwd());
		System.out.println(pass);
		System.out.println(userVo.getEmail()+"/"+userVo.getPwd());
		if(loginedVo.getPwd().equals(pass)) {
			userService.updateUser(userVo);
			req.getSession().invalidate();
			return "success";
		}else return "failed";
		
	}
	
	
//	인증번호 or 임시비밀번호 전송 
	public String sendMail(UserVo userVo,HttpServletResponse res, String type) {
		String setfrom = "hm.oh@codexbridge.com";       
	 	String key = new TempKey().getKey(10, false);
	 	
	    String tomail  = userVo.getEmail();     // 받는 사람 이메일
	    String title = null;
	    String content = null;
		if(type == "signup") {
		    title = "인증번호 발급 입니다.";
		    content = new StringBuffer().
		    		append("인증번호를 입력해주세요.\n 인증번호  : ").
		    		append(key).
		    		toString();
		}else {
			title = "임시비밀번호 재발급 입니다.";
		    content = new StringBuffer().
		    		append("임시비밀번호로 로그인해주세요.\n 임시비밀번호  : ").
		    		append(key).
		    		toString();
		}
	    try {    	
		     res.setContentType("UTF-8");		      
			 PrintWriter writer = res.getWriter();	      
			  writer.print(key);	
		      MimeMessage message = mailSender.createMimeMessage();
		      MimeMessageHelper messageHelper = new MimeMessageHelper(message, true, "UTF-8");
		 
		      messageHelper.setFrom(setfrom);  // 보내는사람 생략하거나 하면 정상작동을 안함 두번째 인자값은 보낼때의 이름이다.
		      messageHelper.setTo(tomail);     // 받는사람 이메일
		      messageHelper.setSubject(title); // 메일제목은 생략이 가능
		      messageHelper.setText(content);  // 메일 내용
		     
		      mailSender.send(message);      
			}catch(Exception e){
		      System.out.println(e);
		    }
	    return key;
	}
}

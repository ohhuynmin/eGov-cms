package egovframework.example.sample.service;

import egovframework.example.sample.vo.FileVo;

public interface FileMapper {
	FileVo selectFile(FileVo fileVo) throws Exception;
	void addFile(FileVo fileVo) throws Exception;
	void deleteFile(String fileId) throws Exception;
}

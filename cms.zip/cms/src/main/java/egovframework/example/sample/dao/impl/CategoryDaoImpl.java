package egovframework.example.sample.dao.impl;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import egovframework.example.sample.dao.CategoryDao;
import egovframework.example.sample.service.CategoryMapper;
import egovframework.example.sample.vo.CategoryVo;

@Repository
public class CategoryDaoImpl implements CategoryDao{
	 @Autowired
	 private SqlSession sqlSession;
	 CategoryMapper mapper;
	@Override
	public List<CategoryVo> selectCategoryList() throws Exception {
		mapper = sqlSession.getMapper(CategoryMapper.class);
		return mapper.selectCategoryList();
	}

	@Override
	public CategoryVo selectCategory(CategoryVo categoryVo) throws Exception {
		mapper = sqlSession.getMapper(CategoryMapper.class);
		return mapper.selectCategory(categoryVo);
	}

	@Override
	public void createCategory(CategoryVo categoryVo) throws Exception {
		mapper = sqlSession.getMapper(CategoryMapper.class);
		mapper.createCategory(categoryVo);
	}

	@Override
	public void deleteCategory(CategoryVo categoryVo) throws Exception {
		mapper = sqlSession.getMapper(CategoryMapper.class);
		mapper.deleteCategory(categoryVo);
	}

	@Override
	public List<CategoryVo> selectMainCategoryList() throws Exception {
		mapper = sqlSession.getMapper(CategoryMapper.class);
		return mapper.selectMainCategoryList();
	}

	@Override
	public List<CategoryVo> selectSubCategoryList(int main_id) throws Exception {
		mapper = sqlSession.getMapper(CategoryMapper.class);
		return mapper.selectSubCategoryList(main_id);
	}

}

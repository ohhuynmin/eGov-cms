package egovframework.example.sample.service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Calendar;
import java.util.UUID;
import org.springframework.util.FileCopyUtils;


public class FileUpload {
	public static String fileUpload(String uploadPath, String originalName, byte[] fileData) throws Exception {
		UUID uuid = UUID.randomUUID();
		String saveName = uuid.toString()+"_"+originalName;		//파일명 랜덤한 UUID로 중복방지  
		System.out.println(saveName);
		String savedPath = calcPath(uploadPath);		//날짜별 디렉토리 생성
		System.out.println(savedPath);
		File target = new File(savedPath, saveName);		//파일 경로(업로드경로+날짜)
		FileCopyUtils.copy(fileData, target);		//임시디렉토리에 업로드파일임시저장 
		String formatName = originalName.substring(originalName.lastIndexOf('.')+1);	//파일 확장자 찾기 
//		String uploadFileName = null;	//추후 썸네일 추가시 사용예정
		if(MediaUtils.getMediaType(formatName) != null) {
//			uploadFileName = makeThumnail(uploadPath,savedPath, saveName);		//이미지 썸네일 생성 
		}else {
//			uploadFileName = makeIcon(uploadPath,savedPath, saveName);		// 나머지는 아이콘 생성 
		}
//		return uploadFileName;
		return saveName;
	}
	
	public static String calcPath(String uploadPath) {
		Calendar cal = Calendar.getInstance();
		// File.separator = \\ (디렉터리 구분자) 
		String yearPath = ""+cal.get(Calendar.YEAR);
		System.out.println(yearPath);
		String monthPath = File.separator + cal.get(Calendar.MONTH);
		String datePath = File.separator + cal.get(Calendar.DATE);
		
		makeDir(uploadPath, yearPath, monthPath, datePath);
		
		return uploadPath+yearPath+monthPath+datePath;
	}
	
	
	private static void makeDir(String uploadPath, String... paths) {	//디렉터리 생성 
		if(new File(paths[paths.length-1]).exists()) {
			return;
		}
		String path = "";
		for(String p : paths) {
			path += p;
			File dirPath = new File(uploadPath + path);
			System.out.println(dirPath);
			if(!dirPath.exists()) {
				dirPath.mkdir();			
			}
		}					
	}
//	private static String makeThumbnail(String filePath, String fileName,String formatName) {
//		if(MediaUtils.getMediaType(formatName) != null) {
//			BufferedImage sourceImg = ImageIO.read(new File(filePath,fileName));
//			
//		}
//		return "";
//	}
	public static void deleteFile(String filePath, String fileName) {
		Path path = Paths.get(filePath+"/"+fileName);
		try {
			Files.delete(path);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}

package egovframework.example.sample.service;

import java.security.MessageDigest;
import org.apache.commons.codec.binary.Base64;

public class CryptPassword {
	
	public static String encrypt(String password, String id) throws Exception{	//암호화 
		if(password == null || id == null) return "";
		byte[] hashValue = null;
		MessageDigest md = MessageDigest.getInstance("SHA-256");
		md.reset();
		md.update(id.getBytes());
		
		hashValue = md.digest(password.getBytes());
		return new String(Base64.encodeBase64(hashValue));
	}
	
	public String randamPassword(int length) {
		
		return "";
	}
}


package egovframework.example.sample.dao;

import java.util.List;

import egovframework.example.sample.vo.ReplyVo;

public interface ReplyDao {
	public List<ReplyVo> replyList(ReplyVo replyVo) throws Exception;
	public int count(ReplyVo replyVo) throws Exception;
	public void createReply(ReplyVo replyVo) throws Exception;
	public void deleteReply(ReplyVo replyVo) throws Exception;
}

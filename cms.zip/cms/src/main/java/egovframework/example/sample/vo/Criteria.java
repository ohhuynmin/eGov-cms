package egovframework.example.sample.vo;

public class Criteria {
	private int currentPage;
	private int showCnt;
	private int skip;	//limit로 조회시 자원낭비발생 -> skip 지정으로 자원낭비 제거
	private int totalCnt;
	private int totalPage;
	public Criteria() {
		this.currentPage = 1;
		this.showCnt = 5;
		this.skip = 0;
	}

	public Criteria(int currentPage, int showCnt) {
		this.currentPage = currentPage;
		this.showCnt = showCnt;
		this.skip = (currentPage-1)*showCnt;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.skip = (currentPage-1)*showCnt;
		this.currentPage = currentPage;
	}

	public int getShowCnt() {
		return showCnt;
	}
	public void setShowCnt(int showCnt) {
		this.skip = (this.currentPage-1)*showCnt;
		this.showCnt = showCnt;
	}
	public int getSkip() {
		return skip;
	}
	public void setSkip(int skip) {
		this.skip = skip;
	}
	public void setTotalCnt(int totalCnt) {
		this.totalCnt = totalCnt;
		setTotalPage((int)Math.ceil(totalCnt/this.showCnt));
	}
	public int getTotalCnt() {
		return totalCnt;
	}

	public int getTotalPage() {
		return totalPage;
	}

	public void setTotalPage(int totalPage) {
		this.totalPage = totalPage;
	}

	@Override
	public String toString() {
		return "Criteria [currentPAge="+currentPage+", showCnt="+showCnt+", skip="+skip+"]";
	}
}

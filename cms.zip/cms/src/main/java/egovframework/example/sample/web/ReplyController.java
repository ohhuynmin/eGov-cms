package egovframework.example.sample.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import egovframework.example.sample.service.ReplyService;
import egovframework.example.sample.vo.ReplyVo;

@Controller
public class ReplyController {
	@Autowired
	private ReplyService replyService;
	
	@RequestMapping(value="addReply.do")
	public String addReply(ReplyVo replyVo, Model model) throws Exception{
		replyService.createReply(replyVo);
		model.addAttribute("replyList", replyService.replyList(replyVo));
		return "userPage/reply";
	}
	@RequestMapping(value="replyList.do")
	public String replyList(ReplyVo replyVo, Model model, @RequestParam(value="boardNo") int boardNo) throws Exception{
		replyVo.setBoardNo(boardNo);
		model.addAttribute("replyList", replyService.replyList(replyVo));
		return "userPage/reply";
	}
	@RequestMapping(value="deleteReply.do")
	public void deleteReply(@RequestParam(value="id")int id) throws Exception{
		ReplyVo replyVo = new ReplyVo();
		replyVo.setId(id);
		replyService.deleteReply(replyVo);
	}
}

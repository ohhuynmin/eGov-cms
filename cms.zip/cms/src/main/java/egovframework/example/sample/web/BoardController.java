package egovframework.example.sample.web;

import java.io.FileInputStream;
import java.io.InputStream;

import org.apache.commons.compress.utils.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import egovframework.example.sample.service.BoardService;
import egovframework.example.sample.service.CategoryService;
import egovframework.example.sample.service.FileService;
import egovframework.example.sample.service.FileUpload;
import egovframework.example.sample.service.MediaUtils;
import egovframework.example.sample.service.ReplyService;
import egovframework.example.sample.vo.BoardVo;
import egovframework.example.sample.vo.CategoryVo;
import egovframework.example.sample.vo.FileVo;
import egovframework.example.sample.vo.ReplyVo;
import egovframework.example.sample.vo.SearchVo;

@Controller
public class BoardController {
	@Autowired
	private BoardService boardService;
	@Autowired
	private CategoryService categoryService;
	@Autowired
	private FileService fileService;
	@Autowired
	private ReplyService replyService;
		
	
	//테이블 리스트 조회
	@RequestMapping(value="tableListView.do")
	public String boardListView(Model model, @RequestParam(value="category", defaultValue="dashboard")String category
				, @RequestParam(required = false)String searchType
				, @RequestParam(required = false)String keyword) throws Exception{
		
		SearchVo searchVo = new SearchVo();
		searchVo.setCategory(category);
		if(searchType != null && keyword != null) {
			searchVo.setSearchType(searchType);
			searchVo.setSearchKeyword(keyword);
		}
		searchVo.setTotalCnt(boardService.countBoard(searchVo));
		model.addAttribute("categoryVo", selectCategory(category));
		model.addAttribute("boardList", boardService.selectBoardList(searchVo));
		model.addAttribute("pagenation", searchVo);
		
		if(selectCategory(category).getType() != 3)
			return "userPage/tableList";
		else return "userPage/gridList";
	}
	//페이징처리
	@RequestMapping(value="boardTable.do")
	public String boardTable(Model model, CategoryVo categoryVo, @RequestParam(value="category", defaultValue="dashboard")String category
			, @RequestParam(required = false, defaultValue="1")int currentPage
			, @RequestParam(required = false, defaultValue="5")int showCnt
			, @RequestParam(required = false)String searchType
			, @RequestParam(required = false)String keyword) throws Exception{
		
		SearchVo searchVo = new SearchVo();
		searchVo.setCategory(category);
		searchVo.setCurrentPage(currentPage);
		searchVo.setShowCnt(showCnt);
		searchVo.setSearchType(searchType);
		searchVo.setSearchKeyword(keyword);
		searchVo.setTotalCnt(boardService.countBoard(searchVo));
		categoryVo.setName(category);
		model.addAttribute("categoryVo", categoryService.selectCategory(categoryVo));
		model.addAttribute("boardList", boardService.selectBoardList(searchVo));
		model.addAttribute("pagenation", searchVo);
		
		return "userPage/boardTable";
	}
	
	
	//게시글 조회
	@RequestMapping(value="selectBoardView.do")
	public String selectBoardView(Model model, BoardVo boardVo, @RequestParam(value = "id")int id) throws Exception{
		boardVo.setId(id);
		model.addAttribute("Flag", "view");
		model.addAttribute("boardVo", boardService.selectBoard(boardVo));
		return "userPage/boardDetail";
	}
	@RequestMapping(value="createBoardView.do")
	public String createBoardView(Model model, BoardVo boardVo, @RequestParam(value="category") String category) throws Exception{
		model.addAttribute("categoryVo", selectCategory(category));
		model.addAttribute("boardVo", boardVo);
		model.addAttribute("Flag", "add");
		return "userPage/boardDetail";
	}
	@RequestMapping(value="/createBoard.do")
	public String createBoard(BoardVo boardVo, FileVo fileVo) throws Exception{
		System.out.println(boardVo.getUploadFile());
	   if (boardVo.getUploadFile() != null) {
		   uploadFile(boardVo, fileVo);
	    }
		boardService.createBoard(boardVo);
		return "redirect:/tableListView.do?category="+boardVo.getCategory();
	}
	
	@RequestMapping(value="updateBoardView.do")
	public String updateBoardView(Model model, BoardVo boardVo, @RequestParam(value="id") int id
								, @RequestParam(value="category") String category) throws Exception{
		boardVo.setId(id);
		model.addAttribute("Flag", "modify");
		model.addAttribute("boardVo", boardService.selectBoard(boardVo));
		model.addAttribute("categoryVo", selectCategory(category));
		return "userPage/boardDetail";
	}
	@RequestMapping(value="updateBoard.do")
	public String updateBoard(BoardVo boardVo, FileVo fileVo) throws Exception{
		MultipartFile uploadFile = boardVo.getUploadFile();
        if (!uploadFile.isEmpty()) {
        	uploadFile(boardVo, fileVo);
        }
        boardService.updateBoard(boardVo);
		return "redirect:/tableListView.do?category="+boardVo.getCategory();
	}
	
	@RequestMapping(value = "deleteBoard.do")
	public String deleteBoard(@RequestParam(value="id") int id) throws Exception{
		BoardVo boardVo = new BoardVo();
		boardVo.setId(id);
		BoardVo selectVo = boardService.selectBoard(boardVo);
		if(selectVo.getFileId() != null && selectVo.getFileId() != "") {		//첨부파일 삭제
			FileVo fileVo = new FileVo();
			fileVo.setId(selectVo.getFileId());
			FileVo selectFile = fileService.selectFile(fileVo);
	        String filePath = selectFile.getPath();
	        String fileName = selectVo.getFileId() +"_"+ selectFile.getName();
	        FileUpload.deleteFile(filePath, fileName);
			fileService.deleteFile(selectVo.getFileId());
		}
		ReplyVo replyVo = new ReplyVo();
		replyVo.setBoardNo(id);
		replyService.deleteReply(replyVo);
		boardService.deleteBoard(selectVo);
		return "redirect:/tableListView.do?category="+selectVo.getCategory();
	}
	@RequestMapping(value = "showImage.do", method=RequestMethod.GET)
	public ResponseEntity<byte[]> showImage(FileVo fileVo,@RequestParam(value="fileId") String fileId) throws Exception{
		InputStream inputStream = null;
		ResponseEntity<byte[]> entity = null;
		fileVo.setId(fileId);
		FileVo selectFile = fileService.selectFile(fileVo);
		if(selectFile != null) {
			String fileName= selectFile.getName();
			try {
				String formatString = fileName.substring(fileName.lastIndexOf('.')+1);
				MediaType mType = MediaUtils.getMediaType(formatString);
				HttpHeaders headers = new HttpHeaders();
				String file = selectFile.getPath()+"/"+selectFile.getId()+"_"+selectFile.getName();
				inputStream = new FileInputStream(file);
				if(mType != null) {
					headers.setContentType(mType);
				}else {
					headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
					headers.add("Content-Disposition","attachment; filename=\""+ new String(fileName.getBytes("UTF-8"), "ISO-8859-1")+"\"");
				}
				entity = new ResponseEntity<byte[]>(IOUtils.toByteArray(inputStream),headers, HttpStatus.CREATED);
			}catch (Exception e) {
				e.printStackTrace();
				entity = new ResponseEntity<byte[]>(HttpStatus.BAD_REQUEST);
			}finally {
				inputStream.close();
			}
		}
		return entity;
	}
	
	private void uploadFile(BoardVo boardVo, FileVo fileVo) throws Exception{
		 MultipartFile uploadFile = boardVo.getUploadFile();
		String fileName = FileUpload.fileUpload("/usr/local/upload/", uploadFile.getOriginalFilename(), uploadFile.getBytes());
    	boardVo.setFileId(fileName.substring(0,fileName.indexOf('_')));
    	boardVo.setFileName(fileName.substring(fileName.indexOf('_')+1));
        fileVo.setId(boardVo.getFileId());
        fileVo.setName(boardVo.getFileName());
        fileVo.setPath(FileUpload.calcPath("/usr/local/upload/"));
        fileService.addFile(fileVo);
	}
	
	private CategoryVo selectCategory(String category) throws Exception{
		CategoryVo categoryVo = new CategoryVo();
		categoryVo.setName(category);
		return categoryService.selectCategory(categoryVo);
	}
}

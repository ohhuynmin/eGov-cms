package egovframework.example.sample.web;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.ui.Model;

import egovframework.example.cmmn.JsonUtil;
import egovframework.example.sample.service.BoardService;
import egovframework.example.sample.service.CategoryService;
import egovframework.example.sample.service.FileService;
import egovframework.example.sample.service.FileUpload;
import egovframework.example.sample.service.ReplyService;
import egovframework.example.sample.vo.BoardVo;
import egovframework.example.sample.vo.CategoryVo;
import egovframework.example.sample.vo.FileVo;
import egovframework.example.sample.vo.ReplyVo;
import egovframework.example.sample.vo.SearchVo;

@Controller
public class CategoryController {
	@Autowired
	private CategoryService categoryService;
	@Autowired 
	private BoardService boardService;
	@Autowired
	private FileService fileService;
	@Autowired
	private ReplyService replyService;
	
//	게시판 관리 페이지
	@RequestMapping(value="/categoryManagement.do")
	public String boardManagement(Model model) throws Exception{
		model.addAttribute("categoryList", categoryService.selectCategoryList());
		return "sample/categoryManagement";
	}
//	카테고리 생성 페이지
//	jstl form의 commend에 빈vo 객체를 넘겨주고 vo객체로 받음
	@RequestMapping(value = "createCategoryView.do")
	public String createCategoryView(CategoryVo categoryVo, Model model) throws Exception{
		model.addAttribute("categoryVo", categoryVo);
		model.addAttribute("MainCategoryList",categoryService.selectMainCategoryList());
		return "sample/createCategory";
	}
//	카테고리 생성
	@RequestMapping(value = "createCategory.do")
	public String createCategory(CategoryVo categoryVo) throws Exception{
			categoryService.createCategory(categoryVo);
		return "redirect:/categoryManagement.do";
	}
//	카테고리 이름 중복확인
	@RequestMapping(value = "checkCategory.do")
	public @ResponseBody CategoryVo checkCategory(CategoryVo categoryVo)throws Exception{
		CategoryVo checkVo = categoryService.selectCategory(categoryVo);
		if(checkVo != null)
			return categoryService.selectCategory(categoryVo);
		else return null;
	}
	@RequestMapping(value="selectCategory.do")
	public @ResponseBody CategoryVo selectCategory(CategoryVo categoryVo) throws Exception{
		CategoryVo selectVo = categoryService.selectCategory(categoryVo);
		return selectVo;
	}
	@RequestMapping(value="deleteCategory.do")
	public String deleteCategory(CategoryVo categoryVo,@RequestParam(value="categoryId[]") List<String> categoryId) throws Exception{
		for(int i=0;i<categoryId.size();i++) {
			categoryVo.setId(Integer.parseInt(categoryId.get(i)));
			delCategory(categoryVo);
			categoryService.deleteCategory(categoryVo);
		}
		
		return "redirect:/categoryManagement.do";
	}
	@RequestMapping(value="selectMainCategoryList.do")
	public void selectMainCategoryList(HttpServletResponse res)throws Exception{
		PrintWriter out = null;
		res.setCharacterEncoding("UTF-8");
		List<?> MainmenuList = categoryService.selectMainCategoryList();
		out = res.getWriter();
		out.write(JsonUtil.ListToJson(MainmenuList));
	}
	@RequestMapping(value="selectSubCategoryList.do")
	public void selectSubCategoryList(HttpServletResponse res,@RequestParam(value="main_id") int main_id)throws Exception{
		PrintWriter out = null;
		res.setCharacterEncoding("UTF-8");
		List<?> SubmenuList = categoryService.selectSubCategoryList(main_id);
		out = res.getWriter();
		out.write(JsonUtil.ListToJson(SubmenuList));
	}
	
	
//	카테고리 내부 board, file, reply삭제
	private void delCategory(CategoryVo categoryVo) throws Exception{
		SearchVo searchVo = new SearchVo();
		searchVo.setCategory(categoryVo.getName());
		List<BoardVo> list = boardService.selectBoardList(searchVo);
		for(int i=0;i<list.size();i++) {
			BoardVo selectVo = boardService.selectBoard(list.get(i));
			deleteFile(selectVo);
			deleteReply(selectVo);
			boardService.deleteBoard(selectVo);
		}
	}
	private void deleteFile(BoardVo boardVo) throws Exception {
		if(boardVo.getFileId() != null) {		//첨부파일 삭제
			FileVo fileVo = new FileVo();
			fileVo.setId(boardVo.getFileId());
			FileVo selectFile = fileService.selectFile(fileVo);
	        String filePath = selectFile.getPath();
	        String fileName = boardVo.getFileId() +"_"+ selectFile.getName();
	        FileUpload.deleteFile(filePath, fileName);
			fileService.deleteFile(boardVo.getFileId());
		}
	}
	private void deleteReply(BoardVo boardVo) throws Exception{
		ReplyVo replyVo = new ReplyVo();
		replyVo.setBoardNo(boardVo.getId());
		replyService.deleteReply(replyVo);
	}
}

package egovframework.example.sample.service;

import java.util.List;

import egovframework.example.sample.vo.ReplyVo;

public interface ReplyMapper {
	List<ReplyVo> replyList(ReplyVo replyVo) throws Exception;
	int count(ReplyVo replyVo) throws Exception;
	void createReply(ReplyVo replyVo) throws Exception;
	void deleteReply(ReplyVo replyVo) throws Exception;
}

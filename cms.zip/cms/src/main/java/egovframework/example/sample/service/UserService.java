package egovframework.example.sample.service;

import java.util.List;

import egovframework.example.sample.vo.UserVo;

public interface UserService {
	public UserVo login(UserVo userVo) throws Exception;
	public void signup(UserVo userVo) throws Exception;
	public void signout(UserVo userVo) throws Exception;
	public void updateUser(UserVo userVo) throws Exception;
	public UserVo findPwd(UserVo userVo) throws Exception;
	public List<UserVo> userList() throws Exception;
}

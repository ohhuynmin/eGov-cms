package egovframework.example.sample.service;

import java.util.List;

import egovframework.example.sample.vo.BoardVo;
import egovframework.example.sample.vo.SearchVo;

public interface BoardMapper {
	List<BoardVo> selectBoardList(SearchVo searchVo) throws Exception;
	BoardVo selectBoard(BoardVo boardVo) throws Exception;
	void createBoard(BoardVo boardVo) throws Exception;
	void deleteBoard(BoardVo boardVo) throws Exception;
	void updateBoard(BoardVo boardVo) throws Exception;
	int countBoard(SearchVo searchVo) throws Exception;
}

package egovframework.example.sample.dao.impl;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import egovframework.example.sample.dao.FileDao;
import egovframework.example.sample.service.FileMapper;
import egovframework.example.sample.vo.FileVo;

@Repository
public class FileDaoImpl implements FileDao{
	 @Autowired
	 private SqlSession sqlSession;
	 FileMapper mapper;
	 
	@Override
	public FileVo selectFile(FileVo fileVo) throws Exception {
		mapper = sqlSession.getMapper(FileMapper.class);
		return mapper.selectFile(fileVo);
	}
	@Override
	public void addFile(FileVo fileVo) throws Exception {
		mapper = sqlSession.getMapper(FileMapper.class);
		mapper.addFile(fileVo);
	}
	@Override
	public void deleteFile(String fileId) throws Exception {
		mapper = sqlSession.getMapper(FileMapper.class);
		mapper.deleteFile(fileId);
	}
	 
}

package egovframework.example.sample.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import egovframework.example.sample.dao.ReplyDao;
import egovframework.example.sample.service.ReplyService;
import egovframework.example.sample.vo.ReplyVo;

@Service
public class ReplyServiceImpl implements ReplyService{
	@Autowired
	ReplyDao replyDao;
	
	@Override
	public List<ReplyVo> replyList(ReplyVo replyVo) throws Exception {
		return replyDao.replyList(replyVo);
	}

	@Override
	public int count(ReplyVo replyVo) throws Exception {
		return replyDao.count(replyVo);
	}

	@Override
	public void createReply(ReplyVo replyVo) throws Exception {
		replyDao.createReply(replyVo);
	}

	@Override
	public void deleteReply(ReplyVo replyVo) throws Exception {
		replyDao.deleteReply(replyVo);
	}

}

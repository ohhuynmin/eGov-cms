package egovframework.example.sample.dao;

import java.util.List;

import egovframework.example.sample.vo.BoardVo;
import egovframework.example.sample.vo.SearchVo;

public interface BoardDao {
	
	public List<BoardVo> selectBoardList(SearchVo searchVo) throws Exception;
	public BoardVo selectBoard(BoardVo boardVo) throws Exception;
	public void createBoard(BoardVo boardVo) throws Exception;
	public void deleteBoard(BoardVo boardVo) throws Exception;
	public void updateBoard(BoardVo boardVo) throws Exception;
	public int countBoard(SearchVo searchVo) throws Exception;
}

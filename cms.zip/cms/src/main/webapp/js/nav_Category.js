	$.ajax({
		url: "selectMainCategoryList.do",
		async: false,
		success: function(result){
			var jsonRes = JSON.parse(result);
			var strMainCategory ="";
			$.each(jsonRes, function(i,item){
				var strSubCategory = subCategory(item.id);
				if(strSubCategory != ""){
					strMainCategory += "<li class='dropdown-submenu'><a tabindex='-1' href='tableListView.do?category="
										+item.name+"' class='dropdown-submenu-toggle'>"
										+item.name+"<b class='caret'></b></a>"
										+"<ul class='dropdown-menu'><li><a href='tableListView.do?category="+item.name+"'>"+item.name+"</a></li>"
										+strSubCategory+"</ul></li>";
				}else{
					strMainCategory += "<li><a href='tableListView.do?category="+item.name+"'>"+item.name+"</a></li>";
				}
			});
			$('#categoryList').append(strMainCategory);
		}
	})
	function subCategory(id){
		var strSub = "";
	 	$.ajax({
			url: "selectSubCategoryList.do",
			async: false,
			data: {main_id: id},
			success: function(result){
				if(result.length != 2){
					var jsonRes = JSON.parse(result);
					$.each(jsonRes, function(i, item){
						strSub += "<li><a href='tableListView.do?category="+item.name+"'>"+item.name+"</a></li>";
					})
				}
			}
		})
		return strSub;
	}
function fn_signout(){
		var check = confirm('탈퇴 하시겠습니까?');
		if(check){
			var pwd = prompt('비밀번호를 입력해주세요.');
			$.ajax({
				url: "signout.do",
				data: {email: '${user.email}', pwd: pwd},
				success: function(result){
					if(result == "success"){
						alert('회원탈퇴 완료!');
						location.href="home.do";
					}else{
						alert()
					}
				}
			})
		}
	}
	function fn_change_pwd(){
		if($('#cur_pwd').val() == null || $('#cur_pwd').val() ==''){
			alert('현재 비밀번호를 입력해주세요');
			$('#cur_pwd').focus();
			return;
		}
		if($('#userPwd').val() == null || $('#userPwd').val() ==''){
			alert('변경할 비밀번호를 입력해주세요');
			$('#userPwd').focus();
			return;
		}
		$.ajax({
			url: "updateUser.do",
			data: {email: $('#userEmail').val(), pwd: $('#userPwd').val(), cur_pwd: $('#cur_pwd').val()},
			success: function(result){
				if(result == 'success'){
					alert('변경완료! 변경된 비밀번호로 로그인 해주세요.');
					location.href="logout.do";
				}else{
					alert('비밀번호를 다시 확인해주세요.');
				}
			}
			
		})
	}
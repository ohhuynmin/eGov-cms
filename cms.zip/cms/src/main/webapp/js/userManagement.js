	$(document).ajaxStop(function(){
		location.reload(); 
	});


function fn_permissionUp_user(){
		var userId = new Array();
		var list = $("input[name='checkId']:checked");
		var authority= null;
		for(var i=0; i<list.length;i++){
			authority = list[i].parentNode.parentNode.children[4].textContent;
			console.log(authority);
			if(list[i].checked && authority != 'manager'){
				console.log(list[i].value);
				userId.push(list[i].value);
			}		
			if(authority == 'manager'){
				alert('선택된 유저는 이미 관리자입니다.');
				return;
			}
		}
		for(var i=0; i<userId.length; i++)
			console.log(userId[i]);
		if(userId.length != 0){
			var chk = confirm("정말 변경 하시겠습니까?");
			if(chk){
				console.log(userId)
				 $.ajax({
				    	type: "POST",
				    	data: {userId: userId, authority: "manager"},
				    	url: "changeAuthority.do",
				    	success: function(){
				    		alert("권한이 변경 되었습니다.");
				    	}
				    });    	       
			}
		}else alert("선택된 유저가 없습니다.");
	}
	function fn_permissionDown_user(){
		var userId = new Array();
		var list = $("input[name='checkId']");
		
		for(var i=0; i<list.length;i++){
			var authority = $("input[name='checkId']")[i].parentNode.parentNode.children[4].textContent;
			if(list[i].checked && authority != 'user'){
				userId.push(list[i].value);
			}		
		}
		for(var i=0; i<userId.length; i++)
			console.log(userId[i]);
		if(userId.length != 0){
			var chk = confirm("정말 변경 하시겠습니까?");
			if(chk){
				console.log(userId)
				 $.ajax({
				    	type: "POST",
				    	data: {userId: userId, authority: "user"},
				    	url: "changeAuthority.do",
				    	success: function(){
				    		alert("권한이 변경 되었습니다.");				
				    	}
				    });    	        
			}
		}else alert("선택된 유저가 없습니다.");	
	}
	
	
	$(function(){
		var checkboxs = document.getElementsByName("checkId")
		var ListCount = checkboxs.length;
		
		$("input[name='AllcheckId']").click(function(){
			var checkedArr = $("input[name='checkId']");
			for(var i=0; i<checkedArr.length;i++){
				checkedArr[i].checked = this.checked;
			}
		});
		$("input[name='checkId']").click(function(){
			if($("input[name='checkId']:checked").length == ListCount){
				$("input[name='AllcheckId']")[0].checked = true;
			}else{
				$("input[name='AllcheckId']")[0].checked = false;
			}
		})
	});		
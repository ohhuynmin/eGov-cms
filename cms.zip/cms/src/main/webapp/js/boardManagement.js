$(function(){
		var checkboxs = document.getElementsByName("checkId")
		var ListCount = checkboxs.length;
		
		$("input[name='AllcheckId']").click(function(){
			var checkedArr = $("input[name='checkId']");
			for(var i=0; i<checkedArr.length;i++){
				checkedArr[i].checked = this.checked;
			}
		});
		$("input[name='checkId']").click(function(){
			if($("input[name='checkId']:checked").length == ListCount){
				$("input[name='AllcheckId']")[0].checked = true;
			}else{
				$("input[name='AllcheckId']")[0].checked = false;
			}
			var id = this.value;
			var checkedchild = $("input[id=sel_childOf"+id+"]");
			for(var i=0; i<checkedchild.length;i++){
				checkedchild[i].checked = this.checked;
			}
		})
	});		
	function fn_delete_category(){
		var categoryId = new Array();
		var list = $("input[name='checkId']");
		for(var i=0; i<list.length;i++){
			if(list[i].checked){
				categoryId.push(list[i].value);
			}
		}
		if(categoryId.length != 0){
			var chk = confirm("정말 삭제하시겠습니까?");
			if(chk){
				 $.ajax({
				    	type: "POST",
				    	data: {categoryId: categoryId},
				    	url: "deleteCategory.do",
				    	success: function(data){
				    		alert("삭제 되었습니다.");
							location.reload(); 
				    	}
				    });    	        
			}
		}else alert("선택된 글이 없습니다. ");	
	}
		function subCategory(id){
			var strSub = "";
			var type="";
		 	$.ajax({
				url: "selectSubCategoryList.do",
				async: false,
				data: {main_id: id},
				success: function(result){
					if(result.length != 2){
						var jsonRes = JSON.parse(result);
						$.each(jsonRes, function(i, item){
							switch(item.type){
							case 1: type="일반 게시판";break;
							case 2: type="공지 사항";break;
							case 3: type="갤러리";break;
							}
							strSub += "<tr id='childOf"+id+"'>"
									+"<td>ㄴ<input id='sel_childOf3' type='checkbox' name='checkId' value='"+item.id+"'/></td>"
									+"<td>"+item.id+"</td>"
									+"<td>"+item.name+"</td>"
									+"<td>"+item.description+"</td>"
									+"<td>"+type+"</td>"
									+"<td align='center'>"+item.file_yn+"</td>"
									+"</tr>";
						})
					}else{
						strSub += "<tr id='childOf"+id+"'>"
								+"<td colspan='7' style='text-align:center;'>하위 메뉴가 존재하지 않습니다.</td></tr>";
					}
					$('#parent'+id).after(strSub);
				}
			})
	}
	function postnTr(id){
	    if ($('#postnTab'+id).text() == "▼"){
	    	subCategory(id);
	        $('#postnTab'+id).text("▲");
	    }
	    else {
	    	if(document.querySelectorAll('#childOf'+id).length != 0){
	    		for(i=0;i<=document.querySelectorAll('#childOf'+id).length;i++)
		    		$('#childOf'+id).remove();
	    	}else{
	    		$('#childOf'+id).remove();
	    	}
	        $('#postnTab'+id).text("▼");
	    }    
	}
	
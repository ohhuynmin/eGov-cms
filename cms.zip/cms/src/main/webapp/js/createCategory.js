$("input[name='Main_yn']:radio").change(function () {
	var value = $(this).val();
	if(value == "Yes"){
		$('#parent_id').css("display","none");
	}else{
		$('#parent_id').css("display","");
	}
});

function fn_check_category(){
	var main_yn = $("input[name='Main_yn']:checked").val();
	var name = document.getElementById('name').value;
	if(document.getElementById('parent_id').value == 0 && main_yn == "No"){
		alert('메인 카테고리를 선택해주세요.')
		document.CategoryForm.reset();
		$('#parent_id').css("display","none");
		return;
	}else{
		$.ajax({
			url: "checkCategory.do",
			data: "name="+name,
			success: function(data){
				if(data == null || data == ''){
					document.CategoryForm.submit();
				}else{
					alert('이미 존재하는 게시판 입니다.');
					document.CategoryForm.reset();
				}
			}
		})
	}
}